/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   player.cpp
 * Author: Alex
 * 
 * Created on 27 de marzo de 2017, 18:55
 */

#include <iostream>
#include "player.h"

using namespace sf;

player::player(float posX, float posY){
    pos_Player.x = posX/2;
    pos_Player.y = posY/2;
    vel_Player = 3;
    
    if (!t_Player.loadFromFile("resources/spriteverde.png")){
        std::cerr << "Error cargando la imagen sprite.png\n";
        exit(0);
    }
    
    s_Player.setTexture(t_Player);
    
    s_Player.setOrigin(128/2,128/2);
    
    s_Player.setTextureRect(sf::IntRect(128*0, 128*0, 128, 128));
    
    s_Player.setPosition(pos_Player);
    //s_Player.setScale(0.5,0.5);
}

void player::moverDerecha(){
    pos_Player.x += vel_Player;
    s_Player.setTextureRect(sf::IntRect(128*2, 128*0, 128, 128));
}

void player::moverIzquierda(){
    pos_Player.x -= vel_Player;
    s_Player.setTextureRect(sf::IntRect(128*3, 128*0, 128, 128));
}

void player::moverArriba(){
    pos_Player.y -= vel_Player;
    s_Player.setTextureRect(sf::IntRect(128*1, 128*0, 128, 128));
}

void player::moverAbajo(){
    pos_Player.y += vel_Player;
    s_Player.setTextureRect(sf::IntRect(128*0, 128*0, 128, 128));
}

Vector2f player::getPosition(){
    return pos_Player;
}

void player::update(){
    s_Player.setPosition(pos_Player);
    
}

void player::draw(RenderWindow &window){
    window.draw(s_Player);
}
