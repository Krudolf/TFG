/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   aro.cpp
 * Author: Alex
 * 
 * Created on 27 de marzo de 2017, 18:55
 */

#include <iostream>
#include <SFML/Graphics.hpp>
#include "aro.h"
#include "player.h"
#include <math.h>

using namespace sf;

aro::aro(float posX, float posY){
    position.x=posX;
    position.y=posY;
    
    if (!texAro.loadFromFile("resources/spritearo.png"))
    {
        std::cerr << "Error cargando la imagen aro.png";
        exit(0);
    }
    //spriteAro.setTexture(texAro);
    spriteAro.setTexture(texAro);
   
    
    spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    spriteAro.setOrigin(128/2, 128/2);
    //Lo posiciono en la terminal
    spriteAro.setPosition(position);
    //spriteAro.setScale(0.5,0.5);
}
void aro::draw(RenderWindow &window){
    window.draw(spriteAro);
}


void aro::posicion(float posX, float posY){
    position.x=posX;
    position.y=posY;
    //Lo posiciono en la terminal
    spriteAro.setPosition(posX, posY);
}

void aro::posicion2(float posX, float posY){
    position.x=posX;
    position.y=posY;
    
}

FloatRect aro::bounding(){
    sf::FloatRect boundingBox = spriteAro.getGlobalBounds();
    

return boundingBox;
}


Sprite aro::getSpriteAro(){
    return spriteAro;
}
void aro::charAtaque(char a){
    c=a;
}
void aro::ataque(){
    if(c=='w'){
        position.y -= velAro*2;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='s'){
        position.y += velAro*2;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='a'){
        position.x -= velAro*2;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }
    if(c=='d'){
        position.x += velAro*2;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }

    if(c=='m'){

        position.x = position.x + (length * cos(angle));
        position.y = position.y + (length * sin(angle));
        spriteAro.setTextureRect(sf::IntRect(1*128, 0*128, 128, 128));
        angle += angle_stepsize;
        
        spriteAro.setPosition(position.x,position.y);
   
    }

   

    
}
void aro::update(){
    spriteAro.setPosition(position);
}

float aro::getangle(){

return angle;
}