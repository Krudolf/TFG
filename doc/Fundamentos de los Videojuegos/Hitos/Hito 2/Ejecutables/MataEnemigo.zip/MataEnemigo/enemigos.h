/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   enemigos.h
 * Author: Alex
 *
 * Created on 1 de mayo de 2017, 17:06
 */

#include <SFML/Graphics.hpp>

using namespace sf;

class enemigos {
public:
    enemigos(float posX, float posY);
    
    Vector2f getPosition();
    
    void update();
    
    void draw(RenderWindow &window);
    
    Vector2f normalize(const Vector2f& source);
    
    void mover(Vector2f pos_Player, float inter);
    
    FloatRect bounding();
    
    void danyo(int danyo);
    
   
private:
    Vector2f pos_Enemigo;
    
    float vel_Enemigo;
    
    int vida;
    
    Texture t_Enemigo;
    
    Sprite s_Enemigo;

};