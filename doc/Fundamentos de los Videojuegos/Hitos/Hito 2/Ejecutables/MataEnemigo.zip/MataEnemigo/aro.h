/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include <SFML/Graphics.hpp>

#ifndef ARO_H
#define ARO_H

using namespace sf;

class aro{
    private:
        Vector2f position;
        float inix;
        float iniy;
        sf::Sprite spriteAro;
        sf::Texture texAro;
        float velAro=3;
        char c;

            //////////

        bool verde1=false;
        float length = 70;
        float x,y;
        float angle = 0.0;
        float angle_stepsize = 0.05;
        const float pi = 3.1415927;
        
        
    
    public:
        aro(float posX, float posY);
        void draw(RenderWindow &window);
        void posicion(float posX, float posY);
        void posicion2(float posX, float posY);
        
        FloatRect bounding();
        Sprite getSpriteAro();
        void update();
        void charAtaque(char a);
        void ataque();
        float getangle();
};
#endif /* ARO_H */


