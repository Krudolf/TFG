#include <SFML/Graphics.hpp>

#ifndef ARO_H
#define ARO_H

using namespace sf;

class aro{
    private:
        Vector2f position;
        Vector2f posAnterior;
        Vector2f posInter;
        sf::Sprite spriteAro;
        sf::Texture texAro;
        float velAro=0.1;
        char c;
        sf::Int32 dt;
    
    public:
        aro(float posX, float posY);
        void draw(RenderWindow &window, float incTime);
        void posicion(float posX, float posY);
        Sprite getSpriteAro();
        void update();
        void charAtaque(char a, sf::Int32 dt);
        void ataque();
};
#endif /* ARO_H */
