#include <cstdlib>
#include <math.h>
#include <iostream>
#include <SFML/Graphics.hpp>

#include "player.h"
#include "enemigos.h"
#include "mapGame.h"

using namespace std;

void inputSiempre(sf::RenderWindow &window);
void updateGame(sf::RenderWindow &window, sf::Int32 dt, player &jugador, enemigos &enemigo, mapGame &mapa, mapGame &submapa);
void render(sf::RenderWindow &window, float percentTick, player jugador, enemigos enemigo, mapGame mapa, sf::View vista, mapGame submapa);

int aux=0;

int main(int argc, char** argv){
    const float TICK_TIME = 25;
    
    int width = 1300, height = 800;
    unsigned int FPS = 30;
    float percentTick = 0;
    string urlXML = "resources/mapa.tmx";
    string subUrlXML = "resources/submapa.tmx";
    string urlTiles = "resources/PlantillaMapa.png";
    
    sf::RenderWindow window(sf::VideoMode(width, height), "Alpha");
    window.setFramerateLimit(FPS);
    
    sf::Clock reloj;
    sf::Int32 time, up, lastUp, dt, elapsedTime;
    up = 0;
    lastUp = 0;
    elapsedTime = 0;
    
    player jugador(width, height);
    enemigos enemigo(100, 100);
    mapGame mapa(urlXML, urlTiles);
    mapGame submapa(subUrlXML, urlTiles);
    sf::View vista;
    
    while(window.isOpen()){
        time = reloj.getElapsedTime().asMilliseconds();
        
        if(elapsedTime > TICK_TIME){
            lastUp = up;
            up = reloj.getElapsedTime().asMilliseconds();
            dt = up - lastUp;
            updateGame(window, dt, jugador, enemigo, mapa, submapa);
        }
        inputSiempre(window);
        elapsedTime = time - up;
        percentTick = std::min(1.f, float(elapsedTime)/TICK_TIME);

        render(window, percentTick, jugador, enemigo, mapa, vista, submapa);
    }
    
    return 0;
}

void updateGame(sf::RenderWindow &window, sf::Int32 dt, player &jugador, enemigos &enemigo, mapGame &mapa, mapGame &submapa){
    
    enemigo.update();
    
    int x = jugador.getPosition().x/32;
    int y = jugador.getPosition().y/32;
    
    if(mapa.colisiona(y, x) && aux==0){
        //std::cout<<"chocamos"<<std::endl;
    }
    else{
        jugador.update();
    }
    
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
        jugador.moverDerecha(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
        jugador.moverIzquierda(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
        jugador.moverArriba(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
        jugador.moverAbajo(dt);
    }
    
    
    
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
        aux=1;
        jugador.setPosition(400,400);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::B)){
        aux=0;
        jugador.setPosition(400,400);
    }
    
    
    enemigo.mover(jugador.getPosition(), dt);
}

void inputSiempre(sf::RenderWindow &window){
    sf::Event evento;
    while(window.pollEvent(evento)){
        if(evento.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){
            window.close();
        }
    }
}

void render(sf::RenderWindow &window, float pT, player jugador, enemigos enemigo, mapGame mapa, sf::View vista, mapGame submapa){
    window.clear();
    if(aux==1){
        submapa.setActiveLayer(0);
        submapa.draw(window);
        submapa.setActiveLayer(1);
        submapa.draw(window);
    }else{
        mapa.setActiveLayer(0);
        mapa.draw(window);
        mapa.setActiveLayer(1);
        mapa.draw(window);
    }
    enemigo.draw(window, pT);
    jugador.draw(window, pT);
    vista.setCenter(jugador.getPosition());
    window.setView(vista);
    window.display();
}