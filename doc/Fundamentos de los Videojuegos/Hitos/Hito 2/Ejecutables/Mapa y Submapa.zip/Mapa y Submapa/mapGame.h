#include <SFML/Graphics.hpp>
#include "tinyxml.h"

using namespace std;

class mapGame {
public:
    mapGame(string urlXML, string urlTiles);
    
    TiXmlDocument loadXML(string url);
    
    sf::Texture loadTiles(string url);
    
    void draw(sf::RenderWindow &window);
    
    void setActiveLayer(int layer);
    
    bool colisiona(int y, int x);
    
private:
    int _numLayers;
    int _height;
    int _width;
    int _activeLayer;
    
    sf::Texture _tilesetTexture;
    sf::Sprite**** _tileMapSprite;
};

