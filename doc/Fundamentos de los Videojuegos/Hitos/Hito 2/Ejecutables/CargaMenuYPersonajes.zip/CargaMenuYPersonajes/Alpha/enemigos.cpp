#include <iostream>
#include <math.h>
#include "enemigos.h"
#include <SFML/Graphics.hpp>


enemigos::enemigos(float posX, float posY){
    pos_Enemigo.x = posX;
    pos_Enemigo.y = posY;
    lastPosEnemigo = pos_Enemigo;
    vel_Enemigo = 0.1;
    
    if(!t_Enemigo.loadFromFile("resources/malo-sprite.png")){
        std::cerr << "Error cargando la imagen enemigo.png\n";
        exit(0);
    }
    
    s_Enemigo.setTexture(t_Enemigo);
    s_Enemigo.setOrigin(128/2,128/2);
    //s_Enemigo.setPosition(pos_Enemigo);
    s_Enemigo.setScale(0.5,0.5);
}

void enemigos::mover(sf::Vector2f pos_Player, float dt){
    sf::Vector2f direccion = normalize(pos_Player - pos_Enemigo);
    
    pos_Enemigo = lastPosEnemigo + vel_Enemigo * dt * direccion;
}

sf::Vector2f enemigos::getPosition(){
    return pos_Enemigo;
}

void enemigos::update(){
    lastPosEnemigo = pos_Enemigo;
    //std::cout << "Posicion(" << pos_Enemigo.x << "," << pos_Enemigo.y << ")" << std::endl;
    //std::cout << "LastPosi(" << lastPosEnemigo.x << "," << lastPosEnemigo.y << ")" << std::endl;
}

void enemigos::draw(sf::RenderWindow &window, float incTime){
    posInter = lastPosEnemigo * (1.f - incTime) + pos_Enemigo * incTime;
    s_Enemigo.move(posInter);
    window.draw(s_Enemigo);
}

Vector2f enemigos::normalize(const sf::Vector2f& source){
    float length = sqrt((source.x * source.x) + (source.y * source.y));
    if (length != 0)
        return sf::Vector2f(source.x / length, source.y / length);
    else
        return source;
}

