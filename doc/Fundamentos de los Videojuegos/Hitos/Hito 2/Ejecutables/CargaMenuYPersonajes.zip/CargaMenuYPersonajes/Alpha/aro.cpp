#include <iostream>
#include <SFML/Graphics.hpp>
#include "aro.h"

using namespace sf;

aro::aro(float posX, float posY){
    position.x=posX;
    position.y=posY;
    posAnterior=position;

    
    if (!texAro.loadFromFile("resources/aro.png"))
    {
        std::cerr << "Error cargando la imagen aro.png";
        exit(0);
    }
    //spriteAro.setTexture(texAro);
    spriteAro.setTexture(texAro);
   
    
    spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    spriteAro.setOrigin(128/2, 128/2);
    //Lo posiciono en la terminal
    spriteAro.setPosition(position);
    spriteAro.setScale(0.5,0.5);
    
    std::cout << position.x << "," << position.y << std::endl;
    std::cout << spriteAro.getPosition().x << "," << spriteAro.getPosition().y << std::endl;
}
void aro::draw(RenderWindow &window, float incTime){
    ataque();
    posInter = posAnterior * (1.f - incTime) + position * incTime;
    std::cout << posInter.x << "," << posInter.y << std::endl;
    
    spriteAro.move(posInter);
    spriteAro.setPosition(posInter);
    
    window.draw(spriteAro);
}
void aro::posicion(float posX, float posY){
    position.x=posX;
    position.y=posY;
    //Lo posiciono en la terminal
    spriteAro.setPosition(posX, posY);
}
Sprite aro::getSpriteAro(){
    return spriteAro;
}
void aro::charAtaque(char a, sf::Int32 dtt){
    c=a;
    dt = dtt;
}
void aro::ataque(){
    if(c=='w'){
        position.y = posAnterior.y - velAro*dt;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='s'){
        position.y = posAnterior.y + velAro*dt;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='a'){
        position.x = posAnterior.x - velAro*dt;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }
    if(c=='d'){
        position.x = posAnterior.x + velAro*dt;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }
}
void aro::update(){
    posAnterior=position;
    //spriteAro.setPosition(posInter);
}