#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include "Menu.h"
#include "State.h"
#include "Interfaz.h"
#include "player.h"
#include "enemigos.h"
#include "mapGame.h"
#include "aro.h"


using namespace std;

void inputSiempre(sf::RenderWindow &window);
void updateGame(sf::RenderWindow &window, sf::Int32 dt, player &jugador, enemigos &enemigo);
void render(sf::RenderWindow &window, float percentTick, player jugador, enemigos enemigo, mapGame mapa, sf::View vista,Interfaz interfaz);


int main()
{
    ///////////////////////////////JORDI ANDREA
    
     const float TICK_TIME = 25;
    
    int width = 1300, height = 800;
    unsigned int FPS = 30;
    float percentTick = 0;
    string urlXML = "resources/mapa.tmx";
    string urlTiles = "resources/PlantillaMapa.png";
    
    sf::RenderWindow window(sf::VideoMode(1280, 800), "Alpha");
    window.setFramerateLimit(FPS);
    
    sf::Clock reloj;
    sf::Int32 time, up, lastUp, dt, elapsedTime;
    up = 0;
    lastUp = 0;
    elapsedTime = 0;
    
    player jugador=player(width, height,0);
    int jugadorSeleccionado=0;
    enemigos enemigo(100, 100);
    mapGame mapa(urlXML, urlTiles);
    sf::View vista;
    
    
    
    
    
    
    
    
    ////////////////////////////////////



        
	

	Menu menu(window.getSize().x, window.getSize().y);
        
        State state;
        
        Interfaz interfaz;
      
      
        state.cambiarEstado(1); //inicializo el estado al menu
    
	while (window.isOpen())
	{
		
               if(state.GetEstado()==1){ //EN EL MENU
                   sf::Event event;
		while (window.pollEvent(event))
		{
                    
			switch (event.type)
			{
			case sf::Event::KeyReleased:
				switch (event.key.code)
				{
				case sf::Keyboard::Up:
					menu.MoveUp();
					break;
				case sf::Keyboard::Down:
					menu.MoveDown();
					break;
                                case sf::Keyboard::Left:
					menu.MoveLeft();
                                        //if(menu.GetSelectedMenuCharacter()==1){
                                           
                                       // }
                                        
					break;
                                case sf::Keyboard::Right:
					menu.MoveRight();   
                                        //if(menu.GetSelectedMenuCharacter()==1){
                                        jugadorSeleccionado=menu.GetPersonaje(); //recojo el jugador seleccionado
                                        jugador=player(width, height,jugadorSeleccionado); //le doy a jugador el jugador seleccionado
                                           
                                       // }
                                          
                                           
					break;

				case sf::Keyboard::Return:
                                    int menu_item=menu.GetPressedItem();
                                    int selected_menu=menu.GetSelectedMenu();
                                   
					if(selected_menu==1) //MAIN MENU (1)
					{
                                            switch(menu_item){
                                                case 0:
                                                    menu.SetSelectedMenu(2); //Al presionar voy al PLAY MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                    break;
                                                case 1:
                                                    menu.SetSelectedMenu(3); //Al presionar voy al INSTRUCTIONS MENU
                                                    menu.SetSelectedItem(1); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                   
                                                    break;
                                                    
                                                 case 2:
                                                    menu.SetSelectedMenu(5); //Al presionar voy al CREDITS MENU
                                                    menu.SetSelectedItem(1); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                   
                                                    break;
                                                    
                                                case 3:
                                                
                                                    window.close(); //presiono salir y el juego se sale
                                                    break;
                                                }
					}
                                    else if(selected_menu==3) //INSTRUCTIONS MENU
					{
                                        
                                            switch(menu_item){
                                                case 1:
                                                    menu.SetSelectedMenu(1); //Al presionar voy al MAIN MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                               
                                                }
					}
                                    
                                         else if(selected_menu==2) //PLAYERS MENU
					{
                                        
                                            switch(menu_item){
                                                case 0:
                                                    menu.SetSelectedMenu(4); //Al presionar voy al CHARACTERS MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                                    
                                                 case 1:
                                                    menu.SetSelectedMenu(1); //Al presionar voy al MAIN MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                                    
                                                   
                                               
                                                }
					}
                                          else if(selected_menu==4) //CHARACTERS MENU
					{
                                        
                                            switch(menu_item){
                                                
                                                 case 0:
                                                     if(menu.GetSelectedMenuCharacter()==0){
                                                    menu.SetSelectedMenu(2); //Volver
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                     }
                                                    break;
                                                    
                                                 case 1:
                                                     
                                                     if(menu.GetSelectedMenuCharacter()==0){
                                                       std::cout<<"-------------------"<<std::endl;
                                                       jugador=player(width, height,jugadorSeleccionado); //le doy a jugador el jugador seleccionado
                                                       std::cout<<"-------------------"<<std::endl;
                                                      state.cambiarEstado(2); //CAMBIO ESTADO A MODO JUGAR
                                                    //menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                   // menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                      window.clear();
                                                      window.display();
                                                     }
                                                    break;
                       
                                                   
                                                }
                                           
                                           
                                            
					}
                                    
                                        else if(selected_menu==5) //CREDIT MENU
					{
                                        
                                            switch(menu_item){
                                                 
                                                 case 1:
                                                     
                                                    menu.SetSelectedMenu(1); //Al presionar selecciono al primer personaje
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                     
                                                    break;
                                              
                                                }
					}

					break;
				}

				break;
			case sf::Event::Closed:
				window.close();

				break;

			}
                    }
                    
		}
                else if(state.GetEstado()==2){ //JUGANDO
                                time = reloj.getElapsedTime().asMilliseconds();
                                //jugador=new player(width, height,jugadorSeleccionado);

                    if(elapsedTime > TICK_TIME){
                        lastUp = up;
                        up = reloj.getElapsedTime().asMilliseconds();
                        dt = up - lastUp;
                        updateGame(window, dt, jugador, enemigo);
                    }
                    inputSiempre(window);
                    elapsedTime = time - up;
                    percentTick = std::min(1.f, float(elapsedTime)/TICK_TIME);

                    render(window, percentTick, jugador, enemigo, mapa, vista,interfaz);
                    
                    
                 }

		
                if(state.GetEstado()==1){
                    window.clear();
                    menu.draw(window);
                    window.display();
                }
               /* else if(state.GetEstado()==2){
                    window.clear();
                    interfaz.draw(window);
                    window.display();
                }*/

		
	}

}


void updateGame(sf::RenderWindow &window, sf::Int32 dt, player &jugador, enemigos &enemigo){
    jugador.update();
    enemigo.update();
    
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
        jugador.moverDerecha(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
        jugador.moverIzquierda(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
        jugador.moverArriba(dt);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
        jugador.moverAbajo(dt);
    }
    enemigo.mover(jugador.getPosition(), dt);
}

void inputSiempre(sf::RenderWindow &window){
    sf::Event evento;
    while(window.pollEvent(evento)){
        if(evento.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){
            window.close();
        }
    }
}

void render(sf::RenderWindow &window, float pT, player jugador, enemigos enemigo, mapGame mapa, sf::View vista,Interfaz interfaz){
    window.clear();
    mapa.setActiveLayer(0);
    mapa.draw(window);
    mapa.setActiveLayer(1);
    mapa.draw(window);
    enemigo.draw(window, pT);
    jugador.draw(window, pT);
    vista.setCenter(jugador.getPosition());
    window.setView(vista);
    interfaz.draw(window, vista);
    window.display();
    
}