#include <iostream>
#include "player.h"

player::player(float posX, float posY,int personajeSeleccionado){
    pos_Player.x = posX/2;
    pos_Player.y = posY/2;
    lastPosPlayer = pos_Player;
    vel_Player = 0.2;
    
     if(personajeSeleccionado==0){
        if(!t_Player.loadFromFile("resources/spriteazul.png")){
            std::cerr << "Error cargando la imagen sprite.png\n";
            exit(0);
        }
    }
    
     else if(personajeSeleccionado==1){
        if(!t_Player.loadFromFile("resources/spriteverde.png")){
            std::cerr << "Error cargando la imagen sprite.png\n";
            exit(0);
        }
    }
   
    
    s_Player.setTexture(t_Player);
    
    s_Player.setOrigin(128/2,128/2);
    
    s_Player.setTextureRect(sf::IntRect(128*0, 128*0, 128, 128));
    
    //s_Player.setPosition(pos_Player);

    s_Player.setScale(0.5,0.5); 
}

void player::moverDerecha(sf::Int32 dt){
    pos_Player.x = lastPosPlayer.x + vel_Player * dt;
    s_Player.setTextureRect(sf::IntRect(128*2, 128*0, 128, 128));
}

void player::moverIzquierda(sf::Int32 dt){
    pos_Player.x =  lastPosPlayer.x - vel_Player * dt;
    s_Player.setTextureRect(sf::IntRect(128*3, 128*0, 128, 128));
}

void player::moverArriba(sf::Int32 dt){
    pos_Player.y =  lastPosPlayer.y - vel_Player * dt;
    s_Player.setTextureRect(sf::IntRect(128*1, 128*0, 128, 128));
}

void player::moverAbajo(sf::Int32 dt){
    pos_Player.y =  lastPosPlayer.y + vel_Player * dt;
    s_Player.setTextureRect(sf::IntRect(128*0, 128*0, 128, 128));
}

sf::Vector2f player::getPosition(){
    return pos_Player;
}

void player::update(){
    lastPosPlayer = pos_Player;
    //std::cout << "Posicion(" << pos_Player.x << "," << pos_Player.y << ")" << std::endl;
}

void player::draw(sf::RenderWindow &window, float incTime){
    posInter = lastPosPlayer * (1.f - incTime) + pos_Player * incTime;
    
    s_Player.move(posInter);
    window.draw(s_Player);
}