#include <SFML/Graphics.hpp>

using namespace sf;

class enemigos {
public:
    enemigos(float posX, float posY);
    
    void mover(Vector2f pos_Player, float dt);
    
    Vector2f getPosition();

    void update();
    
    void draw(RenderWindow &window, float incTime);
    
    Vector2f normalize(const Vector2f& source);
    
private:
    Vector2f pos_Enemigo;
    Vector2f lastPosEnemigo;
    Vector2f posInter;
    
    float vel_Enemigo;
    
    Texture t_Enemigo;
    
    Sprite s_Enemigo;

};