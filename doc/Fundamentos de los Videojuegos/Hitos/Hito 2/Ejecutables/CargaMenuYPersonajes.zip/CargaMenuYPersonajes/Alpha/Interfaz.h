#include <SFML/Graphics.hpp>
#ifndef INTERFAZ_H
#define INTERFAZ_H

class Interfaz {
public:
    Interfaz();
    Interfaz(const Interfaz& orig);
    virtual ~Interfaz();
    void draw(sf::RenderWindow &window,sf::View vista);
    void quitarVida(int v){  vida=vida-v;};
    void darVida(int v){ vida=vida+v;};
    
private:
    int vida=100;
    int experiencia=0;
    int nivel=1;
    int oleada=1;
    int enemigos=0;
    sf::Font font;
};

#endif /* INTERFAZ_H */

