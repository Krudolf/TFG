#ifndef STATE_H
#define STATE_H

#pragma once
#include <SFML/Graphics.hpp>

class State {
public:
    State();
    State(const State& orig);
    virtual ~State();
    void cambiarEstado(int estado){ state=estado; }
    int GetEstado(){return state;}
private:
    int state; //1 MENU 2 PLAY
};

#endif /* STATE_H */

