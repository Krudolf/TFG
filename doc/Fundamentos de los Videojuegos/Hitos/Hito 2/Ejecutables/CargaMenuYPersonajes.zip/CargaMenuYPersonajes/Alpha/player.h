#include <SFML/Graphics.hpp>

class player {
public:
    player(float posX, float posY,int personaje);

    void moverDerecha(sf::Int32 dt);
    
    void moverIzquierda(sf::Int32 dt);
    
    void moverArriba(sf::Int32 dt);
    
    void moverAbajo(sf::Int32 dt);
    
    sf::Vector2f getPosition();
    
    void update();
    
    void draw(sf::RenderWindow &window, float incTime);
    
private:
    sf::Vector2f pos_Player;
    sf::Vector2f lastPosPlayer;
    sf::Vector2f posInter;
    
    float vel_Player;
    
    sf::Texture t_Player;
    
    sf::Sprite s_Player;

};