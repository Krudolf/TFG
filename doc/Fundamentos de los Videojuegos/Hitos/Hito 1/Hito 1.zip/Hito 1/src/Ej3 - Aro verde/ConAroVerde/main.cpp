/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alex
 *
 * Created on 27 de marzo de 2017, 18:54
 */

#include "aro.h"
#include "player.h"
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <math.h>
#include <SFML/Graphics.hpp>


using namespace std;
using namespace sf;


int main(int argc, char** argv) {
    int width = 1300;
    int height = 900;
    //Creo la ventana
    RenderWindow window(VideoMode(width, height), "Ejecutable enemigos");
    //Limita el máximo número de fps
    window.setFramerateLimit(60);
    
/* -------------------------------------------- MAPA --------------------------------------------*/
    Texture texturaMapa;
    if (!texturaMapa.loadFromFile("resources/tablero.jpg")){
        std::cerr << "Error cargando la imagen mapa.png\n";
        exit(0);
    }
    Sprite mapa(texturaMapa);
    mapa.setScale(3,3);
    
/* -------------------------------------------- JUGADOR --------------------------------------------*/
    player jugador(width, height);
/* -------------------------------------------- ARO --------------------------------------------*/
    aro aro(jugador.getPosition().x, jugador.getPosition().y);
    //contador
    Clock clock;
    Time time1;
    Time time2;
    int ataque;
    int ataque3;
/* -------------------------------------------- VISTA --------------------------------------------*/
    View vista;
    
    while(window.isOpen()){
    
    //aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
    //ataque = 1;
    //aro.charAtaque('m');
    //aro.ataque();
    

        sf::Event evento;
        while(window.pollEvent(evento)){
            if(evento.type == Event::Closed || Keyboard::isKeyPressed(Keyboard::Escape)){
                window.close();
            }
        }
/* -------------------------------------------- JUGADOR --------------------------------------------*/
        if(Keyboard::isKeyPressed(Keyboard::Right)){
            jugador.moverDerecha();
        }
        if(Keyboard::isKeyPressed(Keyboard::Left)){
            jugador.moverIzquierda();
        }
        if(Keyboard::isKeyPressed(Keyboard::Up)){
            jugador.moverArriba();
        }
        if(Keyboard::isKeyPressed(Keyboard::Down)){
            jugador.moverAbajo();
        }
        if(Keyboard::isKeyPressed(Keyboard::W)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('w');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::S)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('s');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::A)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('a');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::D)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('d');
            }
        }

        if(Keyboard::isKeyPressed(Keyboard::M)){
            if (clock.getElapsedTime()>seconds(1)){
                //aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                //aro.posicion2(jugador.getPosition().x, jugador.getPosition().y);
                
                ataque3=1;
                ataque=1;
                time2 = clock.restart();
                //time2 = clock.restart();
                //aro.charAtaque('m');
                //aro.ataque();

            }
        }

        if(ataque3==1){
        
                aro.posicion2(jugador.getPosition().x, jugador.getPosition().y);
                
                aro.charAtaque('m');
                aro.ataque();

            }

         
        
/* -------------------------------------------- VISTA --------------------------------------------*/
        vista.setCenter(jugador.getPosition());
        
        jugador.update();
        aro.update();
        
        if(clock.getElapsedTime()>seconds(2)){
            ataque = 0;
            ataque3=0;
        }
        
        
        window.clear();
        window.setView(vista);
        window.draw(mapa);

        

if(sin(aro.getangle())>0){
        jugador.draw(window);
        if(ataque==1){
            aro.draw(window);
            aro.ataque();
        }}
        else{
            if(ataque==1){
            aro.draw(window);
            aro.ataque();
            }
            jugador.draw(window);
}
        window.display();
    }
    
    
    return 0;
}


