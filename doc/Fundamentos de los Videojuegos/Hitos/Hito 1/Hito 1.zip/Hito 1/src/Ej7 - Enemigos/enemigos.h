#include <SFML/Graphics.hpp>

using namespace sf;

class enemigos {
public:
    enemigos(float posX, float posY);
    
    Vector2f getPosition();
    
    void update();
    
    void draw(RenderWindow &window);
    
    Vector2f normalize(const Vector2f& source);
    
    void mover(Vector2f pos_Player, float inter);
    
private:
    Vector2f pos_Enemigo;
    
    float vel_Enemigo;
    
    Texture t_Enemigo;
    
    Sprite s_Enemigo;

};