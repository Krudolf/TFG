#include <SFML/Graphics.hpp>
#include <iostream>
#include "Menu.h"

int main()
{
	sf::RenderWindow window(sf::VideoMode(1280, 800), "Alpha");

	Menu menu(window.getSize().x, window.getSize().y);

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{
			switch (event.type)
			{
			case sf::Event::KeyReleased:
				switch (event.key.code)
				{
				case sf::Keyboard::Up:
					menu.MoveUp();
					break;
				case sf::Keyboard::Down:
					menu.MoveDown();
					break;
                                case sf::Keyboard::Left:
					menu.MoveLeft();
					break;
                                case sf::Keyboard::Right:
					menu.MoveRight();
					break;

				case sf::Keyboard::Return:
                                    int menu_item=menu.GetPressedItem();
                                    int selected_menu=menu.GetSelectedMenu();
                                   
					if(selected_menu==1) //MAIN MENU (1)
					{
                                            switch(menu_item){
                                                case 0:
                                                    menu.SetSelectedMenu(2); //Al presionar voy al PLAY MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                    break;
                                                case 1:
                                                    menu.SetSelectedMenu(3); //Al presionar voy al INSTRUCTIONS MENU
                                                    menu.SetSelectedItem(1); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                   
                                                    break;
                                                    
                                                 case 2:
                                                    menu.SetSelectedMenu(5); //Al presionar voy al CREDITS MENU
                                                    menu.SetSelectedItem(1); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                   
                                                    break;
                                                    
                                                case 3:
                                                
                                                    window.close(); //presiono salir y el juego se sale
                                                    break;
                                                }
					}
                                    else if(selected_menu==3) //INSTRUCTIONS MENU
					{
                                        
                                            switch(menu_item){
                                                case 1:
                                                    menu.SetSelectedMenu(1); //Al presionar voy al MAIN MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                               
                                                }
					}
                                    
                                         else if(selected_menu==2) //PLAYERS MENU
					{
                                        
                                            switch(menu_item){
                                                case 0:
                                                    menu.SetSelectedMenu(4); //Al presionar voy al CHARACTERS MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                                    
                                                 case 1:
                                                    menu.SetSelectedMenu(1); //Al presionar voy al MAIN MENU
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                  
                                                    break;
                                                    
                                                   
                                               
                                                }
					}
                                          else if(selected_menu==4) //CHARACTERS MENU
					{
                                        
                                            switch(menu_item){
                                                 
                                                 case 0:
                                                     if(menu.GetSelectedMenuCharacter()==0){
                                                    menu.SetSelectedMenu(2); //Volver
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                     }
                                                    break;
                                                    
                                                 case 1:
                                                     
                                                     if(menu.GetSelectedMenuCharacter()==0){
                                                    exit(0); //ENLAZAR CON EL COMIENZO DE LA PARTIDA
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                     }
                                                    break;
                       
                                                   
                                               
                                                }
					}
                                    
                                        else if(selected_menu==5) //CREDIT MENU
					{
                                        
                                            switch(menu_item){
                                                 
                                                 case 1:
                                                     
                                                    menu.SetSelectedMenu(1); //Al presionar selecciono al primer personaje
                                                    menu.SetSelectedItem(0); //inicializo a 0 el item del menu seleccionado
                                                    menu.DrawNewMenu(window); //dibujo el nuevo menu seleccionado
                                                     
                                                    break;
                                              
                                                }
					}

					break;
				}

				break;
			case sf::Event::Closed:
				window.close();

				break;

			}
		}

		window.clear();

		menu.draw(window);

		window.display();
	}
}