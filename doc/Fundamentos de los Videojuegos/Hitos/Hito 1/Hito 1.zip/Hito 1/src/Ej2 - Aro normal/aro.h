/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   aro.h
 * Author: andrea
 *
 * Created on 23 de marzo de 2017, 18:43
 */
#include <SFML/Graphics.hpp>

#ifndef ARO_H
#define ARO_H

using namespace sf;

class aro{
    private:
        Vector2f position;
        sf::Sprite spriteAro;
        sf::Texture texAro;
        float velAro=3;
        char c;
    
    public:
        aro(float posX, float posY);
        void draw(RenderWindow &window);
        void posicion(float posX, float posY);
        Sprite getSpriteAro();
        void update();
        void charAtaque(char a);
        void ataque();
};
#endif /* ARO_H */

