/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>
#include <SFML/Graphics.hpp>
#include "aro.h"

using namespace sf;

aro::aro(float posX, float posY){
    position.x=posX;
    position.y=posY;
    
    if (!texAro.loadFromFile("resources/aro.png"))
    {
        std::cerr << "Error cargando la imagen aro.png";
        exit(0);
    }
    //spriteAro.setTexture(texAro);
    spriteAro.setTexture(texAro);
   
    
    spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    spriteAro.setOrigin(128/2, 128/2);
    //Lo posiciono en la terminal
    spriteAro.setPosition(position);
    spriteAro.setScale(0.5,0.5);
}
void aro::draw(RenderWindow &window){
    window.draw(spriteAro);
}
void aro::posicion(float posX, float posY){
    position.x=posX;
    position.y=posY;
    //Lo posiciono en la terminal
    spriteAro.setPosition(posX, posY);
}
Sprite aro::getSpriteAro(){
    return spriteAro;
}
void aro::charAtaque(char a){
    c=a;
}
void aro::ataque(){
    if(c=='w'){
        position.y -= velAro*2;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='s'){
        position.y += velAro*2;
        spriteAro.setTextureRect(sf::IntRect(128, 0, 128, 128));
    }
    if(c=='a'){
        position.x -= velAro*2;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }
    if(c=='d'){
        position.x += velAro*2;
        spriteAro.setTextureRect(sf::IntRect(0, 0, 128, 128));
    }
}
void aro::update(){
    spriteAro.setPosition(position);
}