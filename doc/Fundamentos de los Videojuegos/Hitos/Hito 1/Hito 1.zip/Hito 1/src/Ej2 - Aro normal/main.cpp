#include "aro.h"
#include "player.h"
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <math.h>
#include <SFML/Graphics.hpp>


using namespace std;
using namespace sf;


int main(int argc, char** argv) {
    int width = 1300;
    int height = 900;
    //Creo la ventana
    RenderWindow window(VideoMode(width, height), "Ejecutable enemigos");
    //Limita el máximo número de fps
    window.setFramerateLimit(60);
    
/* -------------------------------------------- MAPA --------------------------------------------*/
    Texture texturaMapa;
    if (!texturaMapa.loadFromFile("resources/mapa.png")){
        std::cerr << "Error cargando la imagen mapa.png\n";
        exit(0);
    }
    Sprite mapa(texturaMapa);
    mapa.setScale(3,3);
    
/* -------------------------------------------- JUGADOR --------------------------------------------*/
    player jugador(width, height);
/* -------------------------------------------- ARO --------------------------------------------*/
    aro aro(jugador.getPosition().x, jugador.getPosition().y);
    //contador
    Clock clock;
    Time time1;
    Time time2;
    int ataque;
/* -------------------------------------------- VISTA --------------------------------------------*/
    View vista;
    
    while(window.isOpen()){
        sf::Event evento;
        while(window.pollEvent(evento)){
            if(evento.type == Event::Closed || Keyboard::isKeyPressed(Keyboard::Escape)){
                window.close();
            }
        }
/* -------------------------------------------- JUGADOR --------------------------------------------*/
        if(Keyboard::isKeyPressed(Keyboard::Right)){
            jugador.moverDerecha();
        }
        if(Keyboard::isKeyPressed(Keyboard::Left)){
            jugador.moverIzquierda();
        }
        if(Keyboard::isKeyPressed(Keyboard::Up)){
            jugador.moverArriba();
        }
        if(Keyboard::isKeyPressed(Keyboard::Down)){
            jugador.moverAbajo();
        }
        if(Keyboard::isKeyPressed(Keyboard::W)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('w');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::S)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('s');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::A)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('a');
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::D)){
            if (clock.getElapsedTime()>seconds(1)){
                aro.posicion(jugador.getPosition().x, jugador.getPosition().y);
                ataque = 1;
                time2 = clock.restart();
                aro.charAtaque('d');
            }
        }
        
/* -------------------------------------------- VISTA --------------------------------------------*/
        vista.setCenter(jugador.getPosition());
        
        jugador.update();
        aro.update();
        
        if(clock.getElapsedTime()>seconds(2)){
            ataque = 0;
        }
        
        
        window.clear();
        window.setView(vista);
        window.draw(mapa);
        jugador.draw(window);
        if(ataque==1){
            aro.draw(window);
            aro.ataque();
        }
        window.display();
    }
    
    
    return 0;
}

