#include <SFML/Graphics.hpp>

using namespace sf;

class player {
public:
    player(float posX, float posY);
    
    void moverDerecha(float inter);
    
    void moverIzquierda(float inter);
    
    void moverArriba(float inter);
    
    void moverAbajo(float inter);
    
    Vector2f getPosition();
    
    void update();
    
    void draw(RenderWindow &window);
private:
    Vector2f pos_Player;
    
    float vel_Player;
    
    Texture t_Player;
    
    Sprite s_Player;

};