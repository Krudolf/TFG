#include <iostream>
#include <math.h>
#include "enemigos.h"
#include <SFML/Graphics.hpp>

using namespace sf;

enemigos::enemigos(float posX, float posY){
    pos_Enemigo.x = posX;
    pos_Enemigo.y = posY;
    vel_Enemigo = 4;
    
    if(!t_Enemigo.loadFromFile("resources/malo-sprite.png")){
        std::cerr << "Error cargando la imagen enemigo.png\n";
        exit(0);
    }
    
    s_Enemigo.setTexture(t_Enemigo);
    s_Enemigo.setOrigin(128/2,128/2);
    s_Enemigo.setPosition(pos_Enemigo);
    s_Enemigo.setScale(0.5,0.5);
}

Vector2f enemigos::getPosition(){
    return pos_Enemigo;
}

void enemigos::update(){
    s_Enemigo.setPosition(pos_Enemigo);
}

void enemigos::draw(RenderWindow &window){
    window.draw(s_Enemigo);
}

Vector2f enemigos::normalize(const Vector2f& source){
    float length = sqrt((source.x * source.x) + (source.y * source.y));
    if (length != 0)
        return Vector2f(source.x / length, source.y / length);
    else
        return source;
}

void enemigos::mover(Vector2f pos_Player, float inter){
    Vector2f direccion = normalize(pos_Player - pos_Enemigo);
    
    pos_Enemigo.x += vel_Enemigo * direccion.x * inter;
    pos_Enemigo.y += vel_Enemigo * direccion.y * inter;
    
}
