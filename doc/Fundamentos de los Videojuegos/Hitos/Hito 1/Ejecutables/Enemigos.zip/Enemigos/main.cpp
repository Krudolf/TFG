#include "player.h"
#include "enemigos.h"
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <math.h>
#include <SFML/Graphics.hpp>


using namespace std;
using namespace sf;

#define kVel 5
#define TICKS_PER_SECOND 25
#define SKIP_TICKS 1000/TICKS_PER_SECOND
#define MAX_FRAMESKIP 5

int main(int argc, char** argv) {
    int width = 1300;
    int height = 900;
    
    //Creo la ventana
    RenderWindow window(VideoMode(width, height), "Ejecutable enemigos");
    //Limita el máximo número de fps
    window.setFramerateLimit(60);
    
    //Variables del loop del juego
    Clock clock;
    Int32 next_game_tick = clock.getElapsedTime().asMilliseconds();
    int loops;
    float interpolation;
    
/* -------------------------------------------- MAPA --------------------------------------------*/
    Texture texturaMapa;
    if (!texturaMapa.loadFromFile("resources/mapa.png")){
        std::cerr << "Error cargando la imagen mapa.png\n";
        exit(0);
    }
    Sprite mapa(texturaMapa);
    mapa.setScale(3,3);
    
/* -------------------------------------------- JUGADOR --------------------------------------------*/
    player jugador(width, height);
/* -------------------------------------------- ENEMIGO --------------------------------------------*/
    enemigos enemigo1(width/4, height);
    enemigos enemigo2(width/2, height);
/* -------------------------------------------- VISTA --------------------------------------------*/
    View vista;
    
    while(window.isOpen()){
/* -------------------------------------------- JUGADOR --------------------------------------------*/
        if(Keyboard::isKeyPressed(Keyboard::Right)){
            jugador.moverDerecha(interpolation);
        }
        if(Keyboard::isKeyPressed(Keyboard::Left)){
            jugador.moverIzquierda(interpolation);
        }
        if(Keyboard::isKeyPressed(Keyboard::Up)){
            jugador.moverArriba(interpolation);
        }
        if(Keyboard::isKeyPressed(Keyboard::Down)){
            jugador.moverAbajo(interpolation);
        }
        
        enemigo1.mover(jugador.getPosition(), interpolation);
        enemigo2.mover(jugador.getPosition(), interpolation);
        
        loops = 0;
        while(clock.getElapsedTime().asMilliseconds() > next_game_tick && loops < MAX_FRAMESKIP){
            vista.setCenter(jugador.getPosition());            
            jugador.update();
            enemigo1.update();
            enemigo2.update();
            
            next_game_tick = next_game_tick + SKIP_TICKS;
            ++loops;
            sf::Event evento;
            while(window.pollEvent(evento)){
                if(evento.type == Event::Closed || Keyboard::isKeyPressed(Keyboard::Escape))
                    window.close();
            }
        }
        interpolation = float(clock.getElapsedTime().asMilliseconds() + SKIP_TICKS - next_game_tick) / float(SKIP_TICKS);
        
/* -------------------------------------------- VISTA --------------------------------------------*/

        window.clear();
        window.setView(vista);
        window.draw(mapa);
        jugador.draw(window);
        enemigo1.draw(window);
        enemigo2.draw(window);
        window.display();
    }
    
    
    return 0;
}

