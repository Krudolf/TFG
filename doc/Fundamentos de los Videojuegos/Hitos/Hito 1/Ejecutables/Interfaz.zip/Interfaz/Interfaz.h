#include <SFML/Graphics.hpp>
#ifndef INTERFAZ_H
#define INTERFAZ_H

class Interfaz {
public:
    Interfaz();
    Interfaz(const Interfaz& orig);
    virtual ~Interfaz();
    void draw(sf::RenderWindow &window);
    void quitarVida(int v){  vida=vida-v;};
    void darVida(int v){ vida=vida+v;};
    
private:
    int vida;
    int experiencia;
    int nivel;
    int oleada;
    int enemigos;
    sf::Font font;
};

#endif /* INTERFAZ_H */

