#include <iostream>
#include <SFML/Graphics.hpp>



#define kVel 20

int main()
{
    int width=640;
    int heidth=480;
    //Creamos una ventana 
    sf::RenderWindow window(sf::VideoMode(width, heidth), "P0. Fundamentos de los Videojuegos. DCCIA");

    //camara
    sf::View view;
    //view.reset(sf::FloatRect(280, 200, 400, 300));
   
   
   
    
    //Cargo la imagen donde reside la textura del sprite
    sf::Texture fondo;
    sf::Sprite background;
    fondo.loadFromFile("img/tablero.jpg");
    background.setTexture(fondo);
    
    
    
    
    sf::Texture tex;
    if (!tex.loadFromFile("img/spriteazul.png"))
    {
        std::cerr << "Error cargando la imagen sprites.png";
        exit(0);
    }
    
  
  
   
    //Y creo el spritesheet a partir de la imagen anterior
    sf::Sprite sprite(tex);
    
    //Le pongo el centroide donde corresponde
    sprite.setOrigin(75/2,75/2);
    //Cojo el sprite que me interesa por defecto del sheet
    sprite.setTextureRect(sf::IntRect(0*128, 0*128, 128, 128));

    
    // Lo dispongo en el centro de la pantalla
    sprite.setPosition(width/2, heidth/2);

    

    //Bucle del juego
    while (window.isOpen())
    {
        //Bucle de obtención de eventos
        sf::Event event;
        while (window.pollEvent(event))
        {
            
            switch(event.type){
                
                //Si se recibe el evento de cerrar la ventana la cierro
                case sf::Event::Closed:
                    window.close();
                    break;
                    
                //Se pulsó una tecla, imprimo su codigo
                case sf::Event::KeyPressed:
                    
                    //Verifico si se pulsa alguna tecla de movimiento
                    switch(event.key.code) {
                        
                        //Mapeo del cursor
                      
                        
                         case sf::Keyboard::Left:
                            sprite.setTextureRect(sf::IntRect(3*128, 0*128, 128, 128));
                            //Reflejo vertical
                            sprite.setScale(1,1);
                            sprite.move(-kVel,0);
                            //view.move(-20,0);
                            
                        break;
                        
                        case sf::Keyboard::Right:
                            sprite.setTextureRect(sf::IntRect(2*128, 0*128, 128, 128));
                            //Escala por defecto
                            sprite.setScale(1,1);
                            sprite.move(kVel,0);
                            //view.move(20,0);
                           
                        break;

                      
                        case sf::Keyboard::Up:
                            sprite.setTextureRect(sf::IntRect(1*128, 0*128, 128, 128));
                            sprite.move(0,-kVel);
                            //view.move(0,-20);
                        break;
                        
                        case sf::Keyboard::Down:
                            sprite.setTextureRect(sf::IntRect(0*128, 0*128, 128, 128));
                            sprite.move(0,kVel); 
                            //view.move(0,20);
                        break;
                        
                        
                        //Tecla ESC para salir
                        case sf::Keyboard::Escape:
                            window.close();
                        break;
                        
                        //Cualquier tecla desconocida se imprime por pantalla su código
                        default:
                            std::cout << event.key.code << std::endl;
                        break;
                              
                    }

            }
            
        }
        
        view.setCenter(sprite.getPosition());

        window.clear();
        window.setView(view);
        
        window.draw(background);
        window.draw(sprite);
        
        window.display();
       
    }

    return 0;
}